<a href="{{ route($route) }}" class="text-accent justify-end flex items-center mt-2 hover:underline">
    {{ $text }}
    <i class="fa-solid fa-chevron-right ml-2"></i>
</a>
